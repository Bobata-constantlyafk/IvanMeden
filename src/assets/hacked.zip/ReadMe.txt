Thanks for downloading and don't forget to donate is you liked this font ! -> https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=JF3NNU43JJ7E6

By downloaded the font called HACKED_Title, you agreed this condition :
Like the licence CC-BY saying, if you use this font into a published creation, YOU MUST indicate your source by linking the page http://bit.ly/WatchDogsFont into your credits.

Discover my other works at http://DavidLibeau.fr
Follow me on http://twitter.com/DavidLibeau 